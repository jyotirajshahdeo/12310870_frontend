import React, { useEffect, useState } from 'react';
import axios from 'axios';
import dayjs, { Dayjs } from 'dayjs';
import Chart from 'react-apexcharts';
import { DatePicker, Space } from 'antd';
// import 'antd/dist/reset.css';
import "./App.css";

interface Booking {
  arrival_date_year: number;
  arrival_date_month: string;
  arrival_date_day_of_month: number;
  adults: number;
  children: number;
  babies: number;
  country: string;
}

const App: React.FC = () => {
  const [data, setData] = useState<Booking[]>([]);
  const [startDate, setStartDate] = useState<Dayjs | null>(dayjs().subtract(30, 'day'));
  const [endDate, setEndDate] = useState<Dayjs | null>(dayjs());

  const fetchData = async () => {
    try {
      const res = await axios.get('http://localhost:5000/bookings', {
        params: {
          startDate: startDate?.format('YYYY-MM-DD'),
          endDate: endDate?.format('YYYY-MM-DD'),
        },
      });
      setData(res.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  useEffect(() => {
    fetchData();
  }, [startDate, endDate]);

  const visitorsPerDay = data.reduce((acc, booking) => {
    const date = `${booking.arrival_date_year}-${booking.arrival_date_month}-${booking.arrival_date_day_of_month}`;
    acc[date] = (acc[date] || 0) + booking.adults + booking.children + booking.babies;
    return acc;
  }, {} as Record<string, number>);

  const visitorsPerCountry = data.reduce((acc, booking) => {
    acc[booking.country] = (acc[booking.country] || 0) + booking.adults + booking.children + booking.babies;
    return acc;
  }, {} as Record<string, number>);

  const totalAdults = data.reduce((acc, booking) => acc + booking.adults, 0);
  const totalChildren = data.reduce((acc, booking) => acc + booking.children, 0);

  return (
    <div style={{ padding: '20px' }}>
      <Space direction="horizontal">
        <DatePicker value={startDate} onChange={(date) => setStartDate(date)} />
        <DatePicker value={endDate} onChange={(date) => setEndDate(date)} />
      </Space>

      <div style={{ marginTop: '20px' }}>
        <Chart
          options={{
            chart: { type: 'line', zoom: { enabled: true } },
            xaxis: { categories: Object.keys(visitorsPerDay) },
          }}
          series={[{ name: 'Visitors', data: Object.values(visitorsPerDay) }]}
          type="line"
          height={300}
        />

        <Chart
          options={{
            chart: { type: 'bar' },
            xaxis: { categories: Object.keys(visitorsPerCountry) },
          }}
          series={[{ name: 'Visitors', data: Object.values(visitorsPerCountry) }]}
          type="bar"
          height={300}
        />

        <div style={{ display: 'flex', justifyContent: 'space-around', marginTop: '20px' }}>
          <Chart
            options={{ chart: { type: 'line', sparkline: { enabled: true } } }}
            series={[{ name: 'Adults', data: [totalAdults] }]}
            type="line"
            height={100}
            width={150}
          />

          <Chart
            options={{ chart: { type: 'line', sparkline: { enabled: true } } }}
            series={[{ name: 'Children', data: [totalChildren] }]}
            type="line"
            height={100}
            width={150}
          />
        </div>
      </div>
    </div>
  );
};

export default App;
