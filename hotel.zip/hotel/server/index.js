const express = require('express');
const cors = require('cors');
const fs = require('fs');
const app = express();
const PORT = 5000;

app.use(cors());
const data = JSON.parse(fs.readFileSync('hotel_bookings.json', 'utf-8'));

app.get('/bookings', (req, res) => {
  const { startDate, endDate } = req.query;

  const filteredData = data.filter((booking) => {
    const bookingDate = new Date(
      `${booking.arrival_date_year}-${booking.arrival_date_month}-${booking.arrival_date_day_of_month}`
    );

    return (
      new Date(startDate) <= bookingDate && bookingDate <= new Date(endDate)
    );
  });

  res.json(filteredData);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
